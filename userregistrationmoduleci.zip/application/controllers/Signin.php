<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Signin extends CI_Controller {
    function __construct(){
		parent:: __construct();
		$this->load->model('MLogin', 'login');
		$this->load->helper('url');
		
	}
	/**
	 * Login view.
	 */
	public function index()
	{
		$this->load->view('view_login');
    }
    /**
	 * Login Action.
	 */
	public function dologin()
	{
		$result =  $this->login->dologinModel();
		if($result=="INVALID_LOGIN"){
			echo 'Invalid credentials, please try again -  <a href="'.base_url().'signin"> login </a> !';
		}
		else if($result=="NOT_VERIFIED"){
			echo 'Email not verified, please try again after the verification-  <a href="'.base_url().'signin"> login </a> !';
		}
		else if($result["message"]=="ADMIN"){
			$this->session->set_userdata("userlist",$result["result"]);
			header('Location:'.base_url().'signin/userlist');
		}
		else{
			$this->session->set_userdata("userdetails",$result);
			header('Location:'.base_url().'signin/userdetails'); 
		}
	}
	/**
	 * Front end user view after logging in.
	 */
	public function userdetails(){
		$result['data'] = $this->session->userdata('userdetails');
		$result['role'] = "user";
		$this->load->view('view_user_details',$result); 
	}
	/**
	 * Admin user view after logging in.
	 */
	public function userlist(){
		$result['data'] = $this->session->userdata('userlist');
		$this->load->view('view_user_list',$result); 
	}
	/**
	 * Edit/delete option view for admin.
	 */
	public function useredit($id=""){
		$result['data'] = $this->login->getuserbyid($id);
		$result['role'] = "admin";
		$this->load->view('view_user_details',$result); 
	}
	/**
	 * Edit option action for admin.
	 */
	public function updatesubdata(){
		$result = $this->login->updatedetails();
	}
	/**
	 * Delete option action for admin.
	 */
	public function deletesubdata(){
		$result = $this->login->deletedetails();
	}
	/**
	 * logging out user.
	 */
	public function logout(){
		$this->session->unset_userdata("userdetails");
		$this->session->unset_userdata("userlist");
		$strMessage = "/ User Logged Out !";
		$this->session->set_userdata("loginmessage",$strMessage);
		header('Location:'.base_url().'signin'); 
	}
}
