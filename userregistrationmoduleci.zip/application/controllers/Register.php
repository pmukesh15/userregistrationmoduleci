<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
    function __construct(){
		parent:: __construct();
        $this->load->model('SaveRegister', 'register');
        $this->load->helper('url');
		$this->load->library('session');
		$this->load->library('email');
	}
	/**
	 * Registering the front end/admin users (View).
	 */
	public function index()
	{
		$this->load->view('register_user');
    }
    /**
	 * Registering the front end/admin users (Action).
	 */
	public function dosignup()
	{
	$this->session->set_userdata("usermail",$this->input->post('txtEmail'));
	$strMessage = "/ Login Name ".$this->input->post('txtEmail')." is already registered, Please Login !";
	$this->session->set_userdata("loginmessage",$strMessage);
	$result =  $this->register->doregister();
	
        if($result=="USER_EXIST"){
			header('Location:../signin');
		}
		else{
			$config['protocol']     = 'smtp';
			$config['smtp_host']    = 'ssl://smtp.gmail.com';
			$config['smtp_port']    = '465';
			$config['smtp_timeout'] = '60';
			$config['smtp_user']    = 'thisisrealmukesh@gmail.com';    //username
			$config['smtp_pass']    = 'Mukesh@2020';  //password
			$config['charset']      = 'utf-8';
			$config['newline']      = "\r\n";
			$config['mailtype']     = 'html'; 
			$config['validation']   = TRUE; 

			$emailContent  = '<!DOCTYPE><html><head></head><body><table width="600px" style="border:1px solid #cccccc;margin: auto;border-spacing:0;"><tr><td style="padding-left:3%">Welcome !!! Please verify by clicking - <a href="'.base_url().'register/verifymail/'.$result.'">login</a> </td></tr>';
			$emailContent .='<tr><td style="height:20px"></td></tr>';
   
			$this->email->initialize($config);
			$this->email->set_mailtype("html");
			$this->email->from('mukesh@testmailformachinetest)');
			$this->email->to($this->input->post('txtEmail'));
			$this->email->subject("User Verification");
			$this->email->message($emailContent);
			$this->email->send();
			echo "Successfully registered, please login with link sent to your mail address to verify.";
		}
		
	}
	/**
	 * Registering the front end/admin users (Verify Email).
	 */
	public function verifymail($user_id="")
	{
		$strMessage = "/ Please Login !";
		$this->session->set_userdata("loginmessage",$strMessage);
		$result =  $this->register->verifyemail($user_id);
		if($result){
			echo 'Successfully Verified, please <a href="'.base_url().'signin"> login </a> with your credentials.';
		}
    }
}
