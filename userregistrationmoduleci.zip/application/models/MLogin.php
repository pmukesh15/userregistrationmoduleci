<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class MLogin extends CI_Model{
	public function dologinModel(){
		$this->db->from('tbl_user');
		$this->db->join('tbl_user_subscription', 'tbl_user.pk_int_user_id = tbl_user_subscription.fk_int_user_id','left'); 
		$this->db->where('vchr_email', $this->input->post('txtEmail'));
		$this->db->where('vchr_password', $this->input->post('txtPassword'));
		$query = $this->db->get();
        if($query->num_rows() > 0){
			$returnData = $query->result();
			if($returnData[0]->bln_email_verified!=1){
				return "NOT_VERIFIED";
			}
			if($returnData[0]->int_user_role==0){
				$this->db->from('tbl_user');
				$this->db->where('bln_email_verified', '1');
				$this->db->where('int_user_role', '1');
				$queryAdmin 	           = $this->db->get();
				$returnDataAdmin['result'] = $queryAdmin->result();
				$returnDataAdmin['message']= "ADMIN";
				return $returnDataAdmin;
			}
			return $returnData;
		}
		else{
			return "INVALID_LOGIN";
		}
	}
	public function getuserbyid($id){
		$this->db->from('tbl_user');
		$this->db->join('tbl_user_subscription', 'tbl_user.pk_int_user_id = tbl_user_subscription.fk_int_user_id','left');
		$this->db->where('pk_int_user_id', $id);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return $query->result();
		}
	}
	public function updatedetails(){
		$updateData = array(
			'vchr_title' => $this->input->post('txtTitle'),
			'vchr_url' => $this->input->post('txtUrl'),
			'vchr_story' => $this->input->post('txtStory'),
			'vchr_comment' => $this->input->post('txtComment'),
			'vchr_author' => $this->input->post('txtAuthor')
		);
		$this->db->where('int_subscription_id', $this->input->post('subid'));
		$this->db->update('tbl_user_subscription', $updateData);
		if($this->db->affected_rows() < 0){
			return false;
		}else{
			return true;
		}
	}
	public function deletedetails(){
		$this->db->where('int_subscription_id', $this->input->post('subid'));
		$this->db->delete('tbl_user_subscription');
		if($this->db->affected_rows() < 0){
			return false;
		}else{
			return true;
		}
	}
}