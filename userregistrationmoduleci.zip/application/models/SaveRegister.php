<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class SaveRegister extends CI_Model{

	public function doregister(){
        $this->db->where('vchr_email', $this->input->post('txtEmail'));
        $query = $this->db->get('tbl_user');
        if($query->num_rows() > 0){
			return "USER_EXIST";
		}
		//insert to base table
		$baseField = array(
			'vchr_first_name'=>$this->input->post('txtFirstName'),
            'vchr_last_name'=>$this->input->post('txtLastName'),
            'vchr_email'=>$this->input->post('txtEmail'),
            'vchr_password'=>$this->input->post('txtPassword'),
            'vchr_phone'=>$this->input->post('txtPhone'),
            'dat_dob'=>$this->input->post('datDob'),
            'vchr_subscription'=>$this->input->post('selSubscription'),
            'vchr_country'=>$this->input->post('selCountry'),
			'int_user_role'=>$this->input->post('selRole'));
		$this->db->insert('tbl_user', $baseField);
		$user_id = $this->db->insert_id();
		if($this->db->affected_rows() < 0){
			return false;
		}else{
			//insert to sub table
			$arrSubscription = json_decode($this->input->post('arrSubscription'));
			if(isset($arrSubscription)){
				foreach($arrSubscription as $objSub){
					if($this->input->post('selSubscription')=="comment"){
						$title = $objSub->story_title;
						$text  = $objSub->comment_text;
						$story = $objSub->story_text;
						$url   = $objSub->story_url;
					}
					else if($this->input->post('selSubscription')=="story"){
						$title = $objSub->title;
						$text  = $objSub->comment_text;
						$story = $objSub->story_text;
						$url   = $objSub->url;
					}
					else if($this->input->post('selSubscription')=="poll"){
						
						$title = $objSub->title;
						$text  = $objSub->comment_text;
						$story = $objSub->story_text;
						$url   = $objSub->url;
					}
					$subField = array(
						'fk_int_user_id'=>$user_id,
						'vchr_comment'=>$text,
						'vchr_title'=>$title,
						'vchr_story'=>$story,
						'vchr_url'=>$story,
						'vchr_author'=>$objSub->author);
					$this->db->insert('tbl_user_subscription', $subField);
				}
			}
			return $user_id;
		}
	
	}
	public function verifyemail($id){
		$updateData = array(
			'bln_email_verified' => true
		);
		$this->db->where('pk_int_user_id', $id);
		$this->db->update('tbl_user', $updateData);
		if($this->db->affected_rows() < 0){
			return false;
		}else{
			return true;
		}
	}
}