<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
    <script type="text/javascript"src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script type="text/javascript"src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.js"></script>
    <script type="text/javascript"src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
    <script type="text/javascript"src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/additional-methods.js"></script>
    <script type="text/javascript"src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/additional-methods.min.js"></script>
    <style>
        
        label {
            width:120px;
            display: inline-block;
        }
        #container {
            border: 1px solid #D0D0D0;
            box-shadow: 0 0 8px #D0D0D0;
            width: auto;
            height: auto;
            top: 40%;
            left: 50%;
            transform: translate3d(-50%,-50%, 0);
            position: absolute;
        }
        #body {
            margin: 0 15px 0 15px;
        }
        form{
            margin: 27px 50px 15px 50px;
            max-height: auto;
        }
        .t-a-c{
            text-align: center;
        }
        h1 {
            color: #444;
            background-color: transparent;
            border-bottom: 1px solid #D0D0D0;
            font-size: 19px;
            font-weight: normal;
            margin: 0 0 14px 0;
            padding: 14px 15px 10px 15px;
        }
        input{
            width:170px;
        }
        
        label.error{
            color:red;
            width:100%;
        }
        
    </style>
</head>
<h1 id="txtTitle">LOGIN <?php echo isset($_SESSION['loginmessage'])?$_SESSION['loginmessage']:''; ?></h1>
<body id="body">
    <div id="container">
        <form action ="<?php echo base_url(); ?>signin/dologin" method = "POST" id="frmLogin" name="frmLogin">
        <p>
            <label>
                <span>Email</span>
            </label>
            <input type = "email" id = "txtEmail" name = "txtEmail" value="<?php echo isset($_SESSION['usermail'])?$_SESSION['usermail']:''; ?>" required = "true" />
            <br/>
            <div class="errorLabel"></div>
        </p>
        <p>
            <label>
            <span>Password</span>
            </label>
            <input type = "password" id = "txtPassword" name = "txtPassword" required = "true" minlength="8"/>
            <br/>
            <div class="errorLabel"></div>
        </p>
        <p class="t-a-c">
            <button type="submit" id = "btnSbmit">Login</button>
            <button type="reset" id = "btnReset">Cancel</button>
        </p>
        <p class="t-a-c">
            <a href="<?php echo base_url(); ?>register">Register</a>
        </p>
        </form>
    </div>
</body>
</html>
<script>
validatorRegForm = $("#frmLogin").validate({
        onfocusout: function (element) {
        },
        errorLabelContainer: $("p#errReg"),
        rules: {
            txtEmail: {
                required: true
            },
            txtPassword: {
                required: true
            }

        },
        messages: {
            txtEmail: {
                required: "Email is required"
            },
            txtPassword: {
                required: "Password is required"
            }
        },
        errorPlacement: function(error, element) {
            error.appendTo( element.parent("p").next(".errorLabel") );
            
        }
    });  
</script>
