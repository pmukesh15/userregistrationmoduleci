<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
<script type="text/javascript"src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript"src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.js"></script>
<script type="text/javascript"src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
<script type="text/javascript"src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/additional-methods.js"></script>
<script type="text/javascript"src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/additional-methods.min.js"></script>
    
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	.body {
		margin: 0 15px 0 15px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
    #content-head{
        font-variant: unicase;
        font-size: x-large;
    }
    .detailedView{
        display:none;
    }
	</style>
</head>
<body>

<div id="container">
	<h1>Hi <?php if($role=="user") { echo $data[0]->vchr_first_name; } else { echo "Admin"; } ?>  </h1>
    <h1>Click here to <a href="<?php echo base_url(); ?>signin/logout">Logout</a>!</h2>
    <?php if($role=="user"){ ?>
    <h1 id="content-head"><?php echo $data[0]->vchr_subscription."/s"; ?></h1>
    <?php } ?>
    <?php foreach ($data as $dt){ ?>
    <div class="body">
        <?php if($role=="user"){ ?>
        <strong>
            <?php echo $dt->vchr_title; ?>
        </strong>
        <?php }else{ ?>
        <form name="frm<?php echo $dt->int_subscription_id;  ?>" id="frm<?php echo $dt->int_subscription_id;  ?>"  action="" method="POST">
        <input type="hidden" class="baseURL" value="<?php echo base_url(); ?>signin/">
        <input type="hidden" name="subid" class="subid" value="<?php echo $dt->int_subscription_id; ?>">
        Title
        <br>
        <textarea  name="txtTitle"><?php echo $dt->vchr_title ?> </textarea>
        <br>
        URL
        <br>
        <textarea  name="txtUrl"><?php echo $dt->vchr_url ?> </textarea>
        <br>
        Story
        <br>
        <textarea  name="txtStory"><?php echo $dt->vchr_story ?> </textarea>
        <br>
        Comment
        <br>
        <textarea  name="txtComment"><?php echo $dt->vchr_comment ?> </textarea>
        <br>
        Author
        <br>
        <textarea  name="txtAuthor"><?php echo $dt->vchr_author ?> </textarea>
        <br>
        <p>
            <button type="button" class = "btnSubmit">Update</button>
            <button type="button" class = "btnDelete">Delete</button>
        </p>
        </form>
        <?php } 
        if($role=="user"){ ?>
            <a href="javascript:void(0)" class="viewdetails">+ view details</a>
            <a href="javascript:void(0)" class="hidedetails" style="display:none;">- hide details</a>
            <div class="hidedetails" style="display:none;">
            <?php 
            if($dt->vchr_url!=""){
                echo "URL:".$dt->vchr_url;
                echo "<br>";
            }
            if($dt->vchr_story!=""){
                echo "Story:".$dt->vchr_story;
                echo "<br>";
            }
            if($dt->vchr_comment!=""){
                echo "Cpmment:".$dt->vchr_comment;
                echo "<br>";
            }
            if($dt->vchr_author!=""){
                echo "Author:".$dt->vchr_author;
                echo "<br>";
            }
        }
        ?>
        </div>
    </div>
    <hr>
    <?php } ?>
	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</div>
</body>
</html>
<script>
 $('.viewdetails').click(function(){
    $(this).parent().find('.viewdetails').hide();
    $(this).parent().find('.hidedetails').show();
 });
 $('.hidedetails').click(function(){
    $(this).parent().find('.viewdetails').show();
    $(this).parent().find('.hidedetails').hide();
 });
 // submit the form
$(".btnSubmit").click(function(e) {
e.preventDefault(); // avoid to execute the actual submit of the form.
var subid = $(this).parent().parent().parent().find('.subid').val();
var form = $('#frm'+subid);
var url = $('.baseURL').val()+"updatesubdata";
$.ajax({
       type: "POST",
       url: url,
       data: form.serialize(),
       success: function(data)
       {
        //    alert("Successfully Updated");
       }
     });
     alert("Successfully Updated");
});
//delete
$(".btnDelete").click(function(e) {
e.preventDefault(); // avoid to execute the actual submit of the form.
var subid = $(this).parent().parent().parent().find('.subid').val();
var form = $('#frm'+subid);
var url = $('.baseURL').val()+"deletesubdata";
$.ajax({
       type: "POST",
       url: url,
       data: form.serialize(),
       success: function(data)
       {
           //deleted
       }
     });
     form.remove();
     alert("Successfully Deleted");
});
</script>